# Extreme Mobile Tires Website

React + Vite website for Extreme Mobile Tires.

## Run locally

```bash
npm install
npm run dev
```

## Build for production

```bash
npm run build
```

## Upload to GitHub

Upload all files in this folder to a new GitHub repository. Then connect the repository to Vercel or Netlify.

Recommended deploy settings:

- Framework: Vite
- Build command: `npm run build`
- Output folder: `dist`
